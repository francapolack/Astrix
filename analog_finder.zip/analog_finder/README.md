# Analog Finder

Analog Finder es una aplicación de escritorio (Python + Flet) que busca sitios
terrestres análogos a la Luna o Marte y explica en qué se parecen, en qué
falla la analogía y para qué sirven en una misión.

Los datos incluidos son de ejemplo (`es_ejemplo: true`) y tienen fines
ilustrativos.

## Requisitos

- Python 3.13
- Flet 1.1.2 y flet-map 1.1.2 (ver `requirements.txt`)

## Instalación

```powershell
python -m pip install -r requirements.txt
```

## Ejecución

Desde la carpeta `analog_finder/`:

```powershell
flet run main.py
```

Si `flet` no está en el `PATH` en esta máquina:

```powershell
& "$env:LOCALAPPDATA\Packages\PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\LocalCache\local-packages\Python313\Scripts\flet.exe" run main.py
```

## Pruebas

```powershell
python -m pytest
```

## Uso

1. Elegí un destino (Luna o Marte).
2. Ajustá la importancia de cada parámetro con los sliders de 0 a 10.
   `0` significa "no usar"; de `1` a `10` es el peso en el ranking.
3. Pulsá "Buscar análogos".
4. Revisá el ranking y desplegá cada sitio para ver los textos y las barras.
5. Usá "Ver mapa" para ubicar los sitios y "Volver a resultados" para volver.
6. La barra lateral guarda el historial de búsquedas.

## Límites de la analogía

- Los perfiles, coordenadas y puntajes son datos de ejemplo, no mediciones
  científicas reales.
- Los valores están normalizados entre 0 y 1 y comparan perfiles, no
  condiciones físicas completas.
- Un sitio terrestre no reproduce la gravedad, la atmósfera ni la radiación
  de la Luna o Marte; la analogía es parcial y sirve para planificar pruebas
  y misiones, no para garantizar resultados.
- El mapa depende de un proveedor de tiles remoto; sin conexión se muestra un
  aviso y los marcadores siguen visibles sobre el fondo oscuro.

## Estructura

```text
main.py
core/        lógica de similitud y repositorio de datos
ui/          vistas de búsqueda, resultados y mapa
data/        parámetros, destinos, sitios e historial
tests/       pruebas de lógica y repositorio
```